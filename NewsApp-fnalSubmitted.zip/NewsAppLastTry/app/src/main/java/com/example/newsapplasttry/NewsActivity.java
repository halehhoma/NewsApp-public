package com.example.newsapplasttry;

import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
//import android.support.v4.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
//import android.support.v4.app.LoaderManager.LoaderCallbacks;
//import android.support.v4.content.Loader;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends AppCompatActivity implements LoaderCallbacks<List<News>> {
    //for loging
    private static final String LOG_TAG = NewsActivity.class.getName();
    //Query string with key
    String GUARDIAN_LINK = "https://content.guardianapis.com/search?q=debate&tag=politics/politics&from-date=2014-01-01&api-key=da5ad414-0dc6-476e-bd1b-a9588d47076d";
    private NewsAdapter newsAdapter;
    private int NewsLoader_ID = 1;
    private TextView mEmptyStateTextView;
    private ProgressBar loadingIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        ListView newsListView = (ListView) findViewById(R.id.list);
        newsAdapter = new NewsAdapter(this, new ArrayList<News>());
        newsListView.setAdapter(newsAdapter);

//on Click on Items redirect to main page in Internet
        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                News selectedNews = newsAdapter.getItem(position);
                Uri newsUri = Uri.parse(selectedNews.getUrl());
                Intent webIntent = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(webIntent);
            }
        });


        loadingIndicator = (ProgressBar) findViewById(R.id.loading_indicator);

        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);

// Get a reference to the ConnectivityManager to check state of network connectivity
        ConnectivityManager connMgr =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(NewsLoader_ID, null, this);
        } else {
            /* If there is no internet connection, hide the loading indicator and display
        the NO Internet connection message */
            loadingIndicator.setVisibility(View.GONE);
//            mEmptyStateTextView.setText(R.string.no_internet_connection);


        }


    }


    @Override
    public Loader<List<News>> onCreateLoader(int id, Bundle bundle) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String chooseCategory = sharedPrefs.getString(
                getString(R.string.settings_topic_key),
                getString(R.string.settings_default_topic)
        );
        String orderBy = sharedPrefs.getString(
                getString(R.string.settings_order_by_key),
                getString(R.string.settings_order_by_default));

        Uri baseUri = Uri.parse(GUARDIAN_LINK);
        Uri.Builder uriBuilder = baseUri.buildUpon();
        uriBuilder.appendQueryParameter("from-date", "2019-01-01");
        uriBuilder.appendQueryParameter("q", chooseCategory);
        uriBuilder.appendQueryParameter("show-tags", "contributor");
        uriBuilder.appendQueryParameter("orderBy", orderBy);
        Log.i(LOG_TAG, uriBuilder.toString());

        return new NewsLoader(this, uriBuilder.toString());


//           //     new NewsLoader(this, uriBuilder.toString());
    }


    @Override
    public void onLoadFinished(Loader<List<News>> loader, List<News> news) {

        ProgressBar spinCircle = (ProgressBar) findViewById(R.id.loading_indicator);
        spinCircle.setVisibility(View.GONE);
        newsAdapter.clear();
        if (news != null && !news.isEmpty()) {
//            mEmptyStateTextView.setVisibility(View.GONE);
            newsAdapter.addAll(news);
        }
else {
            mEmptyStateTextView.setText(R.string.no_news_found);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<News>> loader) {
        newsAdapter.clear();
    }

}


