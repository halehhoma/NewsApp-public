package com.example.newsapplasttry;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class NewsAdapter extends ArrayAdapter<News> {

    private static final String DATE_SEPARATOR = "T";
    private static final String LOG_TAG = NewsAdapter.class.getSimpleName();


    public NewsAdapter(Context context, List<News> news) {
        super(context, 0, news);
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        /**
         * ViewHolder for the News layout views.
         */


        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.news_list_item, parent, false);
        }


        // Find the news article at the given position in the list of news
        News currentNews = getItem(position);

        TextView text_webTitle = (TextView) convertView.findViewById(R.id.article_title);
        String title = currentNews.getTitle();
        text_webTitle.setText(title);

        TextView text_sectionName = (TextView) convertView.findViewById(R.id.article_section);
        String sectionName = currentNews.getSection();
        text_sectionName.setText(sectionName);

        TextView authorView = (TextView) convertView.findViewById(R.id.author_name);
        String author = currentNews.getAuthor();
        authorView.setText(author);

        TextView dateView = (TextView) convertView.findViewById(R.id.article_date);
//                String date = currentNews.getDate();
        String date = formatDate(currentNews.getDate());
        dateView.setText(date);

        TextView timeView = (TextView) convertView.findViewById(R.id.article_time);
        String Time = formatTime(currentNews.getDate());
        timeView.setText(Time);
        // Display the section of the current news article in that TextView using viewHolder


        return convertView;
    }

    /**
     * Return the formatted date string (i.e. "Mar 3, 1984") from a Date string.
     */
    private String formatDate(String dateObject) {

        String date = null;

        try {
            Date object = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(dateObject);
            date = new SimpleDateFormat("LLL dd, yyyy").format(object);

        } catch (ParseException e) {
            Log.e(LOG_TAG, "Problem with parsing dateObject to date occurred.");
        }

        return date;
    }

    /**
     * Return the formatted date string (i.e. "4:30 PM") from a Date string.
     */

    private String formatTime(String dateObject) {

        String time = null;

        try {
            Date object = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(dateObject);
            time = new SimpleDateFormat("h:mm a").format(object);

        } catch (ParseException e) {
            Log.e(LOG_TAG, "Problem with parsing dateObject to time occurred.");
        }

        return time;
    }
}




