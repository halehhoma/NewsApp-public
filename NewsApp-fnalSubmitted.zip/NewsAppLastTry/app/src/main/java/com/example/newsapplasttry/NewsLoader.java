package com.example.newsapplasttry;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;




    public class NewsLoader extends AsyncTaskLoader<List<News>> {


        private static final String LOG_TAG = NewsLoader.class.getName();


        private String url;

        /**
         * Constructs a new {@link NewsLoader}.
         *
         * @param context    of the activity
         * @param currentUrl to load data from
         */
        public NewsLoader(Context context, String currentUrl) {
            super(context);
            url = currentUrl;
        }

        @Override
        protected void onStartLoading() {
            forceLoad();
        }


        @Override
        public List<News> loadInBackground() {
            if (url == null) {
                return null;
            }

            // Perform the network request, parse the response, and extract a list of news articles.
            List<News> news = Utils.fetchNewsData(url);
            return news;
        }
}
