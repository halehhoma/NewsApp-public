package com.example.newsapplasttry;

public class News {

    /* News name */
    private String mNewsTitle;

    /* News section */
    private String mNewsSection;

    /* Author name */
    private String mAuthor;

    /* Publication date */
    private String mDate;

    /* Url address */
    private String mUrl;

    /* Constructs a new News object. */
    public News(String NewsTitle, String NewsSection, String author, String date, String url) {
        mNewsTitle = NewsTitle;
        mNewsSection = NewsSection;
        mAuthor = author;
        mDate = date;
        mUrl = url;
    }

    /* Returns the News title. */
    public String getTitle() {
        return mNewsTitle;
    }

    /* Returns the News section. */
    public String getSection() {
        return mNewsSection;
    }

    /* Returns the News author. */
    public String getAuthor() {
        return mAuthor;
    }

    /* Returns the News publication date. */
    public String getDate() {
        return mDate;
    }

    /* Returns the News url. */
    public String getUrl() {
        return mUrl;
    }
}
